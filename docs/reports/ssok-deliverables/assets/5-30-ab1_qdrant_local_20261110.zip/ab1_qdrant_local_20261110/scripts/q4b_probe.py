"""읽기 전용 Qdrant 상태 확인. 값(키) 출력 없음."""
import json, os, sys, requests
url = os.environ["QDRANT_URL"].rstrip("/"); h = {"api-key": os.environ["QDRANT_API_KEY"]}
root = requests.get(url + "/", headers=h, timeout=10).json()
print("server", {k: root.get(k) for k in ("title", "version", "commit")})
cols = requests.get(url + "/collections", headers=h, timeout=10).json()["result"]["collections"]
print("collections", sorted(c["name"] for c in cols))
for c in cols:
    info = requests.get(f"{url}/collections/{c['name']}", headers=h, timeout=10).json()["result"]
    print(c["name"], json.dumps({"status": info["status"], "points": info.get("points_count"), "vectors": info["config"]["params"]["vectors"],
                                "segments": info.get("segments_count"), "payload_schema": sorted(info.get("payload_schema", {}))}, ensure_ascii=False))
snaps = requests.get(url + "/snapshots", headers=h, timeout=10)
print("full snapshots list status", snaps.status_code)
