"""PR #51 공식 평가기(run_model_ab)를 코드 수정 없이 실행한다.
유일한 차이: 고정 주소 상수 embedding_resume.URL(run03 46335)을 이번 로컬 Qdrant 주소로 메모리에서만 바꾼다.
DB 쓰기·Neo4j 호출 없음."""
import json, os, sys
from pathlib import Path
sys.path.insert(0, ".")
from database import embedding_resume as er
from database.retrieval_v140_eval import run_model_ab
er.URL = os.environ["QDRANT_URL"].rstrip("/")
out = Path(sys.argv[1]); env = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
rep = run_model_ab(out, timeout_06b=180.0, timeout_4b=300.0, resume=False, environment=env)
for k, v in rep["results"].items():
    print(k, "recall@5", v["preliminary_recall_at_5"], "mrr@5", v["preliminary_mrr_at_5"],
          "emb", v["embedding"], "search", v["search"], "combined", v["combined"])
