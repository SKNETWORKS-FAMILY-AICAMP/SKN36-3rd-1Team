"""복원된 4B와 0.6B 컬렉션 payload·데이터 정합성 검사(읽기 전용)."""
import json, sys
from collections import Counter
sys.path.insert(0, ".")
from database import handoff_data as hd, full_index as fi
from database.qdrant import store
from database.embedding_resume import scan
from database.retrieval_v140_eval import validate_ab_collections
out = {}
docs = hd.load_documents(verify_hash=True)
bad = [r["file"] for r in hd.verify_manifest_checksums() if not r["matched"]]
out["dataset_version"] = hd.dataset_version(); out["manifest_sha256"] = fi.manifest_sha256(); out["manifest_checksum_mismatch"] = bad
meta = hd.load_payload_metadata()
client = store.get_client()
plans = validate_ab_collections(client, docs, meta)
out["validate_ab_collections"] = {k: {x: v[x] for x in ("ready", "chunks", "expected_chunks", "documents", "policies", "chunk_fingerprint", "model", "dim", "embedding_input_rule", "collection_state")} for k, v in plans.items()}
recs = {n: scan(client, n) for n in ("exp_b2_qwen3emb06b_v140_v1", "exp_b2_qwen3emb4b_v140_v1")}
client.close()
req = ["chunk_id", "document_id", "policy_id", "text", "source_url", "char_start", "char_end", "chunking_version", "embedding_model", "content_hash"]
for n, rec in recs.items():
    p = [r["payload"] for r in rec.values()]
    out[n] = {"points": len(rec), "vector_dims": dict(Counter(len(r["vector"]) for r in rec.values())),
              "missing_fields": {f: sum(1 for x in p if x.get(f) in (None, "")) for f in req},
              "chunking_version": dict(Counter(x.get("chunking_version") for x in p)),
              "embedding_model": dict(Counter(x.get("embedding_model") for x in p)),
              "embedding_dim": dict(Counter(x.get("embedding_dim") for x in p)),
              "documents": len({x["document_id"] for x in p}), "policies": len({x["policy_id"] for x in p}),
              "payload_keys": sorted(set().union(*[x.keys() for x in p]))}
a, b = recs.values()
out["same_point_ids"] = set(a) == set(b)
diff_fields = Counter()
for k in a:
    for f in set(a[k]["payload"]) | set(b[k]["payload"]):
        if a[k]["payload"].get(f) != b[k]["payload"].get(f): diff_fields[f] += 1
out["payload_fields_differing_06b_vs_4b"] = dict(diff_fields)
out["same_text_chunk_doc_policy_span_url_hash"] = all(a[k]["payload"].get(f) == b[k]["payload"].get(f) for k in a for f in ["chunk_id", "document_id", "policy_id", "text", "source_url", "char_start", "char_end", "content_hash"])
hashes = {d["document_id"]: d.get("content_hash") for d in docs} if isinstance(docs, list) else None
print(json.dumps(out, ensure_ascii=False, indent=1))
json.dump(out, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
