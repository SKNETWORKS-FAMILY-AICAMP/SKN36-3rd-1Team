"""run03 · CPU 메모리 재현 · 신규 Qdrant(공식 프로토콜, 3회 반복) 결과를 질문별로 모아 비교한다. 원본 결과 파일만 읽는다."""
import csv, json, sys
from pathlib import Path
R = Path(sys.argv[1])  # 저장소 루트
X = R / "docs/development/experiments"
run03 = json.loads((X / "issue41_ab_run03/summary.json").read_text(encoding="utf-8"))
cpu = json.loads((X / "ab1_b2b3_20261110/ab1_local_compare.json").read_text(encoding="utf-8"))
off = json.loads((X / "ab1_qdrant_local_20261110/official_protocol/summary.json").read_text(encoding="utf-8"))
rep = json.loads((X / "ab1_qdrant_local_20261110/repeat_3rounds.json").read_text(encoding="utf-8"))
alts = json.loads((X / "ab1_b2b3_20261110/alt_spans.json").read_text(encoding="utf-8"))
M = {"0.6b": ("A_B2_V140", "B2_06b"), "4b": ("A_B2_4B_V140", "B2_4b")}
def contains(h, a): return h["document_id"] == a["document_id"] and h["char_start"] is not None and h["char_start"] <= a["char_start"] and a["char_end"] <= h["char_end"]
rows, summary = {}, {}
for k, (cfg, lk) in M.items():
    r3 = {q["question_id"]: q for q in run03["results"][cfg]["questions"]}
    cp = {q["question_id"]: q for q in cpu[lk]["questions"]}
    of = {q["question_id"]: q for q in off["results"][cfg]["questions"]}
    rr = [r for r in rep["rounds"] if r["model"] == k]
    rq = [{q["question_id"]: q for q in r["questions"]} for r in sorted(rr, key=lambda r: r["round"])]
    for qid in of:
        row = rows.setdefault(qid, {"question_id": qid, "answerable": of[qid]["answerable"]})
        if not of[qid]["answerable"]: continue
        row[f"{k}_run03_rank"] = r3[qid]["score"]["first_hit_rank"]
        row[f"{k}_cpu_memory_rank"] = cp[qid]["score5"]["first_hit_rank"]
        row[f"{k}_qdrant_official_rank"] = of[qid]["score"]["first_hit_rank"]
        for i, d in enumerate(rq, 1): row[f"{k}_qdrant_repeat_r{i}_rank"] = d[qid]["score"]["first_hit_rank"]
        row[f"{k}_qdrant_top10_rank"] = rq[0][qid]["score10"]["first_hit_rank"]
        row[f"{k}_qdrant_outcome"] = of[qid]["score"]["outcome"]
        row[f"{k}_qdrant_top5_chunks"] = " | ".join(h["chunk_id"] for h in of[qid]["hits"])
        ex = [h["rank"] for a in alts if a["question_id"] == qid for h in of[qid]["hits"] if contains(h, a)]
        row[f"{k}_proposed_alt_best_rank"] = min(ex) if ex else None
    sc = [q for q in of.values() if q["answerable"]]
    summary[k] = {"collection": off["results"][cfg]["plan"]["collection"], "model": off["results"][cfg]["plan"]["model"],
                  "run03": {"hits": sum(q["score"]["outcome"] == "hit" for q in r3.values() if q["answerable"]), "mrr5": run03["results"][cfg]["preliminary_mrr_at_5"]},
                  "cpu_memory": {"hits": cpu[lk]["recall5"], "mrr5": cpu[lk]["mrr5"]},
                  "qdrant_official": {"hits": sum(q["score"]["outcome"] == "hit" for q in sc), "mrr5": off["results"][cfg]["preliminary_mrr_at_5"],
                                      "rank1": sum(q["score"]["reciprocal_rank"] == 1 for q in sc), "embedding": off["results"][cfg]["embedding"],
                                      "search": off["results"][cfg]["search"], "combined": off["results"][cfg]["combined"]},
                  "qdrant_repeat": rep["summary"][k],
                  "rank_diff_vs_run03": [q for q in rows if rows[q].get("answerable") and rows[q][f"{k}_run03_rank"] != rows[q][f"{k}_qdrant_official_rank"]],
                  "rank_diff_vs_cpu_memory": [q for q in rows if rows[q].get("answerable") and rows[q][f"{k}_cpu_memory_rank"] != rows[q][f"{k}_qdrant_official_rank"]],
                  "fails": [q["question_id"] for q in sc if q["score"]["outcome"] != "hit"]}
out = R / "docs/development/experiments/ab1_qdrant_local_20261110"
json.dump(summary, open(out / "comparison_summary.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
fields = list(dict.fromkeys(f for r in rows.values() for f in r))
with open(out / "per_question_ranks.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); [w.writerow(r) for r in rows.values()]
for k, v in summary.items():
    print(k, v["run03"], v["cpu_memory"], {a: v["qdrant_official"][a] for a in ("hits", "mrr5", "rank1")}, "diff run03", v["rank_diff_vs_run03"], "diff cpu", v["rank_diff_vs_cpu_memory"], "fails", v["fails"])
