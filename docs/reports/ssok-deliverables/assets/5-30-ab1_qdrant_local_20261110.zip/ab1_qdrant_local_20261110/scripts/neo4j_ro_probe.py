"""Neo4j 읽기 전용 확인(READ 트랜잭션만). 자격 증명 출력 없음."""
import json, os, sys
from neo4j import GraphDatabase, READ_ACCESS
d = GraphDatabase.driver(os.environ["NEO4J_URI"], auth=(os.environ["NEO4J_USER"], os.environ["NEO4J_PASSWORD"]))
out = {}
with d.session(default_access_mode=READ_ACCESS) as s:
    out["server"] = s.run("CALL dbms.components() YIELD name, versions, edition RETURN name, versions, edition").data()
    out["nodes"] = s.run("MATCH (n) RETURN count(n) AS c").single()["c"]
    out["relationships"] = s.run("MATCH ()-[r]->() RETURN count(r) AS c").single()["c"]
    out["labels"] = s.run("MATCH (n) UNWIND labels(n) AS l RETURN l, count(*) AS c ORDER BY l").data()
    out["rel_types"] = s.run("MATCH ()-[r]->() RETURN type(r) AS t, count(*) AS c ORDER BY t").data()
d.close()
print(json.dumps(out, ensure_ascii=False)); json.dump(out, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
