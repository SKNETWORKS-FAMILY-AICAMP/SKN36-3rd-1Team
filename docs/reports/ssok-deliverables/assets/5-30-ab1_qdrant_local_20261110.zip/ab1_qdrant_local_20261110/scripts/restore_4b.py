"""4B 스냅샷을 신규 컬렉션 exp_b2_qwen3emb4b_v140_v1에만 복원한다. 키 값은 출력하지 않는다.
중단 조건: 스냅샷 해시/크기 불일치, 대상 컬렉션 이미 존재, 0.6B digest 변화, 복원 실패."""
import hashlib, json, os, sys, time
from datetime import datetime, timezone
import requests
sys.path.insert(0, ".")
from database.qdrant import store
from database.embedding_resume import scan
from database.ab_eval_state import digest

SNAP, LOG = sys.argv[1], sys.argv[2]
TARGET, PROTECTED = "exp_b2_qwen3emb4b_v140_v1", "exp_b2_qwen3emb06b_v140_v1"
EXP_SIZE, EXP_SHA = 30572032, "830b7ad29fda9c7aeda91e39f25be8de43406a35fd836b64163b9fad17aa9ed9"
url = os.environ["QDRANT_URL"].rstrip("/"); h = {"api-key": os.environ["QDRANT_API_KEY"]}
log = {"started_at": datetime.now(timezone.utc).isoformat(), "qdrant_url": url, "target": TARGET, "protected": PROTECTED, "steps": []}
def step(name, **kw):
    log["steps"].append({"step": name, **kw}); print(name, json.dumps(kw, ensure_ascii=False)[:400], flush=True)
def save():
    json.dump(log, open(LOG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
def stop(reason):
    log["result"] = "STOPPED"; log["reason"] = reason; save(); print("STOP", reason); sys.exit(2)

size = os.path.getsize(SNAP); sha = hashlib.sha256(open(SNAP, "rb").read()).hexdigest()
step("snapshot_file", file=os.path.basename(SNAP), size=size, sha256=sha, size_ok=size == EXP_SIZE, sha_ok=sha == EXP_SHA)
if size != EXP_SIZE or sha != EXP_SHA: stop("snapshot hash/size mismatch")
ver = requests.get(url + "/", headers=h, timeout=10).json()["version"]; step("server", version=ver)
names = sorted(c["name"] for c in requests.get(url + "/collections", headers=h, timeout=10).json()["result"]["collections"])
step("collections_before", names=names)
if TARGET in names: stop("target collection already exists")
client = store.get_client()
before = scan(client, PROTECTED)
d_before = digest(before); step("protected_before", points=len(before), digest=d_before)
if d_before != "e1e424fb60df6554b6dcbbb5b3596ca9887b9cc35455c2098e0296ecf079e475": stop("protected digest differs from run03 identity before restore")
t = time.perf_counter()
with open(SNAP, "rb") as fh:
    r = requests.post(f"{url}/collections/{TARGET}/snapshots/upload", params={"priority": "snapshot", "wait": "true"},
                      headers=h, files={"snapshot": (os.path.basename(SNAP), fh, "application/octet-stream")}, timeout=1800)
step("upload_restore", http_status=r.status_code, seconds=round(time.perf_counter() - t, 2), body=r.text[:300])
if r.status_code != 200: stop("restore request failed")
for _ in range(60):
    info = requests.get(f"{url}/collections/{TARGET}", headers=h, timeout=10).json()["result"]
    if info["status"] == "green": break
    time.sleep(2)
step("target_info", status=info["status"], points=info.get("points_count"), vectors=info["config"]["params"]["vectors"], payload_schema=sorted(info.get("payload_schema", {})))
rec = scan(client, TARGET)
step("target_digest", points=len(rec), digest=digest(rec), run03_digest="67eb0a1fba52a545913c5f1d446d719bead9d842d64de7dbc1b3f5be529098d0",
     matches_run03=digest(rec) == "67eb0a1fba52a545913c5f1d446d719bead9d842d64de7dbc1b3f5be529098d0")
after = scan(client, PROTECTED); d_after = digest(after)
step("protected_after", points=len(after), digest=d_after, unchanged=d_after == d_before)
names = sorted(c["name"] for c in requests.get(url + "/collections", headers=h, timeout=10).json()["result"]["collections"])
step("collections_after", names=names)
client.close()
log["result"] = "RESTORED"; log["finished_at"] = datetime.now(timezone.utc).isoformat(); save()
