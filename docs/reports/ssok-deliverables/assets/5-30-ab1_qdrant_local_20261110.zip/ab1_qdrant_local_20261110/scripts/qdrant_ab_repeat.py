"""실제 Qdrant A/B 1 반복 측정: 워밍업 후 3회, 회차마다 모델 순서 교대. DB 쓰기·Neo4j 없음. 키 출력 없음.
- 질문 벡터는 각 컬렉션과 같은 모델로 생성(0.6B→0.6B 컬렉션, 4B→4B 컬렉션)
- 시간: perf_counter. embedding = embedder 호출~검증된 벡터, search = search_chunks(k=5) 호출~반환
- 오류·타임아웃은 0으로 처리하지 않고 errors에 기록, 해당 표본은 시간 통계에서 제외하고 채점은 실패로 기록
- Top-10 진단 검색은 1회차에만, 시간 측정과 별도 호출"""
import json, math, platform, statistics, sys, time, traceback
from datetime import datetime, timezone
import requests
sys.path.insert(0, ".")
from database import embedding as em, handoff_data as hd, retrieval_eval as rv
from database.retrieval_v140_eval import load_cases
from database.qdrant import store
OUT = sys.argv[1]
PLANS = {"0.6b": ("qwen3-embedding:0.6b", 1024, "exp_b2_qwen3emb06b_v140_v1"),
         "4b": ("qwen3-embedding:4b", 2560, "exp_b2_qwen3emb4b_v140_v1")}
base = em.resolve_ollama_base_url().rstrip("/")
docs = hd.load_documents(verify_hash=True)
cases = load_cases(docs, v0_only=True)[0]
assert len(cases) == 55 and sum(c["v0"]["answerable"] for c in cases) == 52
tags = {m["name"]: m["digest"] for m in requests.get(base + "/api/tags", timeout=10).json()["models"]}
embedders = {k: em.make_ollama_embedder(model=v[0], expected_dim=v[1], batch_size=1, timeout=600) for k, v in PLANS.items()}
client = store.get_client()
def p95(v): s = sorted(v); return s[math.ceil(len(s) * .95) - 1] if s else None
def hitrow(h): return {"rank": h["rank"], "score": h["score"], "chunk_id": h["chunk_id"], "document_id": h["document_id"],
                       "policy_id": h["policy_id"], "char_start": h["payload"].get("char_start"), "char_end": h["payload"].get("char_end")}
load = {}
for k, v in PLANS.items():  # 첫 로딩(콜드) 시간은 별도 기록
    t = time.perf_counter(); embedders[k]([cases[0]["query"]]); load[k] = time.perf_counter() - t
rounds, errors = [], []
for rnd in range(1, 4):
    order = ["0.6b", "4b"] if rnd % 2 == 1 else ["4b", "0.6b"]
    for k in order:
        model, dim, coll = PLANS[k]
        for c in cases[:3]:
            embedders[k]([c["query"]])  # 워밍업, 기록 안 함
        ps = [(m["name"], m.get("digest"), m.get("size_vram")) for m in requests.get(base + "/api/ps", timeout=10).json().get("models", [])]
        rows = []
        for c in cases:
            row = {"question_id": c["id"], "answerable": c["v0"]["answerable"]}
            try:
                t = time.perf_counter(); vec = em.validate_vectors(embedders[k]([c["query"]]), 1, dim)[0]; row["embedding_seconds"] = time.perf_counter() - t
                t = time.perf_counter(); hits = store.search_chunks(client, coll, vec, k=5, filters=None); row["search_seconds"] = time.perf_counter() - t
                hits = [hitrow(h) for h in hits]
                row["hits"] = hits; row["score"] = rv.score_question(c["v0"], hits, k=5)
                if rnd == 1:
                    h10 = [hitrow(h) for h in store.search_chunks(client, coll, vec, k=10, filters=None)]
                    row["hits_top10"] = h10; row["score10"] = rv.score_question(c["v0"], h10, k=10)
            except Exception as e:
                row["error"] = f"{type(e).__name__}: {e}"[:300]; errors.append({"round": rnd, "model": k, "question_id": c["id"], "error": row["error"]})
            rows.append(row)
        sc = [r for r in rows if r["answerable"]]
        ok = lambda r: "score" in r and r["score"]["outcome"] == "hit"
        rounds.append({"round": rnd, "model": k, "order": order, "collection": coll, "loaded_models": ps,
                       "recall5_hits": sum(map(ok, sc)), "mrr5": sum(r["score"]["reciprocal_rank"] for r in sc if "score" in r) / 52,
                       "errors": sum("error" in r for r in rows), "questions": rows})
client.close()
summary = {}
for k in PLANS:
    rs = [r for r in rounds if r["model"] == k]
    emb = [q["embedding_seconds"] for r in rs for q in r["questions"] if "embedding_seconds" in q]
    srch = [q["search_seconds"] for r in rs for q in r["questions"] if "search_seconds" in q]
    comb = [q["embedding_seconds"] + q["search_seconds"] for r in rs for q in r["questions"] if "search_seconds" in q]
    st = lambda v: {"samples": len(v), "mean_ms": statistics.mean(v) * 1000, "p95_ms": p95(v) * 1000, "stdev_ms": statistics.stdev(v) * 1000}
    summary[k] = {"embedding": st(emb), "qdrant_search": st(srch), "combined": st(comb),
                  "per_round": [{"round": r["round"], "recall5_hits": r["recall5_hits"], "mrr5": r["mrr5"], "errors": r["errors"],
                                 "mean_embedding_ms": statistics.mean([q["embedding_seconds"] for q in r["questions"] if "embedding_seconds" in q]) * 1000,
                                 "mean_search_ms": statistics.mean([q["search_seconds"] for q in r["questions"] if "search_seconds" in q]) * 1000} for r in rs]}
out = {"created_at": datetime.now(timezone.utc).isoformat(),
       "environment": {"cpu": platform.processor(), "platform": platform.platform(), "python": platform.python_version(),
                       "ollama_version": requests.get(base + "/api/version", timeout=10).json()["version"], "device": "CPU only",
                       "qdrant_server_version": None},
       "models": {k: {"model": v[0], "dim": v[1], "collection": v[2], "digest": tags.get(v[0])} for k, v in PLANS.items()},
       "protocol": {"rounds": 3, "order": "round1 0.6b->4b, round2 4b->0.6b, round3 0.6b->4b", "warmup_queries_per_model_per_round": 3,
                    "questions_per_round": 55, "scored": 52, "top_k": 5, "filters": None, "query_instruction": None, "batch_size": 1,
                    "first_load_seconds_excluded": load, "p95": "nearest rank", "errors_policy": "recorded, excluded from timing, scored as miss"},
       "errors": errors, "summary": summary, "rounds": rounds}
json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k, v in summary.items():
    print(k, {n: (round(x["mean_ms"], 2), round(x["p95_ms"], 2)) for n, x in v.items() if n != "per_round"}, [(r["recall5_hits"], round(r["mrr5"], 6), r["errors"]) for r in v["per_round"]])
print("errors", len(errors), "load", load)
