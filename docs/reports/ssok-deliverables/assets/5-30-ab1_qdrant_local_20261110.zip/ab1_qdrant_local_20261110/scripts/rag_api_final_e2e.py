"""최종 재적재 DB(Qdrant 0.6B + Neo4j) 읽기 전용 FastAPI E2E. 실제 Checker·Generator 코드를 거치고
OpenAI 네트워크 호출(generator._call_openai)만 고정 응답으로 대체한다. 키·비밀번호 출력 없음.
시나리오: health, 정상 질문 3개, 마감 정책 신청 가능 단정 교정, [0001] 인용 정규화, 존재하지 않는 [999] 인용, Qdrant 연결 실패."""
import json, os, sys, time
from unittest.mock import patch
sys.path.insert(0, ".")
from fastapi.testclient import TestClient
import backend.llm.generator as g
import backend.api.main as m

OUT = sys.argv[1]
mode = {"answer": "normal"}
captured = []

def fake_openai(messages):
    data = json.loads(messages[1]["content"].split("\n", 1)[1]); captured.append(data)
    ev = data["official_evidence"]
    if mode["answer"] == "claim_open":
        text = f"{ev[0]['policy_name']}은 지금 신청할 수 있어요 [1]."
    elif mode["answer"] == "zero_pad":
        text = "관련 공식 원문이 있습니다 [0001]."
    elif mode["answer"] == "bad_cite":
        text = "관련 공식 원문이 있습니다 [999]."
    else:
        text = "관련 공식 원문이 있습니다 [1]."
    return json.dumps({"status": "answered", "answer": text, "used_source_ids": [1],
                       "follow_up_questions": [{"kind": "question", "text": "신청 서류는 무엇이 필요한가요?"}]}, ensure_ascii=False)

def summarize(r, dt):
    b = r.json(); row = {"http_status": r.status_code, "seconds": round(dt, 3)}
    if r.status_code != 200:
        row["body"] = b; return row
    cx = captured[-1]["official_evidence"] if captured else []
    row.update({"status": b["status"], "answer": b["answer"],
                "contexts": [{"source_id": x["source_id"], "policy_id": x["policy_id"], "policy_name": x["policy_name"]} for x in cx],
                "policy_checks": [{"policy_id": p["policy_id"], "policy_name": p.get("policy_name"), "reception_status": p["reception_status"]} for p in b["policy_checks"]],
                "citations": b["citations"], "notice": b.get("notice"),
                "follow_up_questions": b["follow_up_questions"],
                "check_set_matches_context_policies": list(dict.fromkeys(x["policy_id"] for x in cx)) == [p["policy_id"] for p in b["policy_checks"]]})
    return row

res = {"description": __doc__, "note": "/health ready는 첫 검색 성공 후 true가 된다(backend/api/main.py search())", "scenarios": []}
def run(c, name, q, prof, answer="normal"):
    mode["answer"] = answer; captured.clear()
    t = time.perf_counter(); r = c.post("/api/ask", json={"question": q, "profile": prof, "history": []}); dt = time.perf_counter() - t
    row = {"scenario": name, "question": q, "profile": prof, "fake_llm_answer_mode": answer, **summarize(r, dt)}
    res["scenarios"].append(row); print(name, row["http_status"], row.get("status"), row.get("answer", row.get("body")), row["seconds"], flush=True)

with patch.object(g, "_call_openai", side_effect=fake_openai), TestClient(m.create_app()) as c:
    h = c.get("/health"); res["health"] = {"http_status": h.status_code, "body": h.json()}; print("health", h.status_code, h.json())
    run(c, "normal_youth_rent", "청년 월세 지원 받을 수 있나요?", {"age": 25, "region": "서울", "income": None})
    h = c.get("/health"); res["health_after_first_search"] = {"http_status": h.status_code, "body": h.json()}; print("health_after", h.status_code, h.json())
    run(c, "normal_gwangju_youth", "광주에 사는 위기 청소년을 위한 특별 지원이 있나요?", {"age": 17, "region": "광주", "income": None})
    run(c, "normal_defector", "북한이탈주민 정착 지원금", {"age": 30, "region": "", "income": 0})
    run(c, "closed_policy_claimed_open", "청년월세 한시 특별지원 지금 신청할 수 있나요?", {"age": 25, "region": "서울", "income": None}, "claim_open")
    run(c, "zero_padded_citation_0001", "청년 월세 지원 받을 수 있나요?", {"age": 25, "region": "서울", "income": None}, "zero_pad")
    run(c, "nonexistent_citation_999", "청년 월세 지원 받을 수 있나요?", {"age": 25, "region": "서울", "income": None}, "bad_cite")

os.environ["QDRANT_URL"] = "http://127.0.0.1:9"  # 닫힌 포트: 연결 실패 재현(실제 DB 영향 없음)
with patch.object(g, "_call_openai", side_effect=fake_openai), TestClient(m.create_app()) as c:
    h = c.get("/health"); res["health_qdrant_down"] = {"http_status": h.status_code, "body": h.json()}; print("health_down", h.status_code, h.json())
    run(c, "qdrant_unreachable", "청년 월세 지원 받을 수 있나요?", {"age": 25, "region": "서울", "income": None})
    h = c.get("/health"); res["health_qdrant_down_after_request"] = {"http_status": h.status_code, "body": h.json()}; print("health_down_after", h.status_code, h.json())
json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
