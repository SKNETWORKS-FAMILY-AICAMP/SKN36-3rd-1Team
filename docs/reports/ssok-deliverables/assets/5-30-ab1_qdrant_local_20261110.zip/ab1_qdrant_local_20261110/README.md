# A/B 1 실제 Qdrant 재시험 (4B 스냅샷 복원 후, 2026-11-10, 나지인)

산출물 05의 "신규 Qdrant 재현" 수치와 산출물 04의 "최종 DB 연동 검증"의 근거 파일이다.
**모든 검색 점수는 예비 결과**다(평가 정답 52문항은 사람 최종 검수 전).

## 1. 무엇을 했나

| 순서 | 작업 | DB 쓰기 | 결과 파일 |
|---|---|---|---|
| 1 | 4B 스냅샷 파일 크기·SHA-256 확인, 대상 컬렉션 부재 확인, 0.6B digest 사전 기록 | 없음 | `restore_log.json` |
| 2 | Qdrant 공식 업로드 복원 API로 **신규 컬렉션 `exp_b2_qwen3emb4b_v140_v1`에만** 복원 | **4B 신규 컬렉션 1개만** | `restore_log.json` |
| 3 | 복원 4B·기존 0.6B payload·데이터 정합성 검사(팀 도구 `validate_ab_collections` 포함) | 없음 | `payload_verification.json` |
| 4 | Neo4j 읽기 전용 개수 확인 | 없음 | `neo4j_readonly_probe.json` |
| 5 | PR #51 공식 평가기 `run_model_ab` 그대로 실행(워밍업 없음, 0.6B→4B 고정 순서) | 없음 | `official_protocol/` |
| 6 | 워밍업 후 3회 반복, 회차마다 모델 순서 교대 측정 | 없음 | `repeat_3rounds.json` |
| 7 | run03 · CPU 메모리 재현 · 신규 Qdrant 질문별 비교 | 없음 | `comparison_summary.json`, `per_question_ranks.csv` |
| 8 | 최종 DB FastAPI E2E(실제 Qdrant·Neo4j·Checker·Generator 코드, OpenAI 호출만 고정 응답) | 없음 | `rag_api_final_db_e2e.json` |
| 9 | RAG/API 범위 테스트 재실행(Mock LLM) | 없음 | `logs/pytest_rag_api_scope.log` |

## 2. 4B 스냅샷 복원 검증 결과

| 항목 | 값 | 판정 |
|---|---|---|
| 스냅샷 파일 | `exp_b2_qwen3emb4b_v140_v1-4804144181564514-2026-11-10-12-35-14.snapshot`, 30,572,032 bytes | 일치 |
| SHA-256 | `830b7ad29fda9c7aeda91e39f25be8de43406a35fd836b64163b9fad17aa9ed9` | 전달받은 값과 일치 |
| Qdrant 서버 | 1.12.4 (컨테이너 `lifepolicy-final-jiin-20261110-qdrant-1`, 127.0.0.1:56336) | — |
| 복원 방법 | `POST /collections/exp_b2_qwen3emb4b_v140_v1/snapshots/upload?priority=snapshot&wait=true` (HTTP 200, 8.08초) | — |
| 복원 전 컬렉션 | `exp_b2_qwen3emb06b_v140_v1` 1개(4B 없음) | 충돌 없음 |
| 4B 컬렉션 | green, 1,138 Point, 2,560차원, Cosine, 색인된 벡터 0(=정확 전수 검색) | 일치 |
| 4B 전체 digest | `67eb0a1fba52a545913c5f1d446d719bead9d842d64de7dbc1b3f5be529098d0` | **run03 identity와 동일** |
| 0.6B digest 복원 전/후 | `e1e424fb60df6554b6dcbbb5b3596ca9887b9cc35455c2098e0296ecf079e475` / 동일 | **변경 없음** |
| payload | 필수 필드 10종 누락 0, `chunking_version=B2` 1,138, `embedding_model=qwen3-embedding:4b` 1,138, 문서 261·정책 246 | 일치 |
| 0.6B vs 4B | Point ID 집합 동일, `chunk_id·document_id·policy_id·text·source_url·char_start·char_end·content_hash` 전부 동일. 다른 필드는 `embedding_model`, `embedding_dim`, `index_run_id` 3개뿐 | 일치 |
| 데이터셋 | `1.4.0-candidate`, manifest `49246d1b…c698389`, manifest 체크섬 불일치 0, `validate_ab_collections` 통과(청크 지문 `ba7e3ef2…`) | 일치 |

## 3. 실행 조건

| 항목 | 값 |
|---|---|
| 코드 | `c50b31b` (`origin/dev` `5a37cf0`와 차이는 `frontend/`·`.gitignore`뿐) |
| 장비 | 이 PC CPU만(Intel64 Family 6 Model 140, NVIDIA GPU 없음), Windows 11, Python 3.12.13 |
| 임베딩 | 로컬 Ollama 0.40.15, `qwen3-embedding:0.6b` digest `ac6da0df…5621d`, `qwen3-embedding:4b` digest `df5bd2e3…ff907` (run03과 같은 digest) |
| 검색 | Vector Top-5, Cosine, 필터 없음, 질의 지시문 없음, 배치 1. 질문 벡터는 각 컬렉션과 같은 모델로 생성 |
| Neo4j | 5.26.32 Community, 노드 1,004 / 관계 2,431 (읽기 전용) |

## 4. 공식 평가기 실행 방식

`scripts/run_official_ab_local.py`는 `database.retrieval_v140_eval.run_model_ab`를 **코드 수정 없이** 호출한다.
유일한 차이는 run03 전용 고정 주소 상수 `database.embedding_resume.URL`(`http://127.0.0.1:46335`)을 이번 Qdrant 주소로 **프로세스 메모리에서만** 바꾼 것이다.
모델 digest 검사, 두 컬렉션 전체 payload 검사, 52문항 분모 검사는 그대로 동작했다.
실행 전 Ollama에서 두 모델을 내려(`keep_alive=0`) run03처럼 첫 질문에 모델 적재 시간이 포함되게 했다.

## 5. 재실행 명령

저장소 루트에서 실행한다. 접속 정보는 셸 환경 변수(`QDRANT_URL`, `QDRANT_API_KEY`, `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`, `OLLAMA_BASE_URL`)로만 넘기고 출력하지 않는다.

```bash
python <이 폴더>/scripts/restore_4b.py <스냅샷 경로> <로그.json>          # 대상 컬렉션이 이미 있으면 중단
python <이 폴더>/scripts/verify_4b_payload.py <출력.json>
python <이 폴더>/scripts/run_official_ab_local.py <새 출력 폴더> <environment.json>
python <이 폴더>/scripts/qdrant_ab_repeat.py <출력.json>
python <이 폴더>/scripts/ab1_compare_all.py <저장소 루트>
python <이 폴더>/scripts/rag_api_final_e2e.py <출력.json>                 # OPENAI_API_KEY 비움
```

`official_protocol/session.lock`, `questions/`, `runs/`는 평가기의 이어하기 기록이며 평가기가 만든 그대로 두었다.
