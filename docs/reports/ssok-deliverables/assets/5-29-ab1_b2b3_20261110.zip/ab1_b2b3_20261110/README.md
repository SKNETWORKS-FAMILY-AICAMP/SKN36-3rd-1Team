# A/B 1(0.6B vs 4B) 재확인 · B2/B3 청킹 비교 원본 결과 (2026-11-10, 나지인)

산출물 05([05_검색평가_AB1_B2B3_나지인_20261110.md](../../../reports/05_검색평가_AB1_B2B3_나지인_20261110.md))의 수치 근거 파일이다.
**모든 수치는 예비 결과**다(평가 정답 52문항 사람 최종 검수 전).

## 실행 조건

| 항목 | 값 |
|---|---|
| 코드 | `origin/dev` `c50b31b` (worktree `final-eval-20261110`) |
| 데이터 | `data/releases/v1.4.0-candidate`, `load_documents(verify_hash=True)` 통과 |
| 질문·정답 | `questions_candidates_v0.jsonl` 55문항 / 채점 52문항, `load_cases(v0_only=True)` 구간 대조 통과 |
| 장비 | 이 PC CPU만 사용(NVIDIA GPU 없음), 로컬 Ollama |
| DB | 최종 재적재 Qdrant(127.0.0.1:56336)는 **읽기만** 했다. 컬렉션 생성·삭제·쓰기 없음. Neo4j 미사용 |

## 파일

| 파일 | 내용 | 만든 방법 |
|---|---|---|
| `verify_run03.json`, `verify_run02.json` | PR #51 run02·run03 summary를 질문별 Top-5로 독립 재계산한 결과(보고값과 일치 여부, 범위별 분리, 질문별 순위) | `scripts/verify_run.py docs/development/experiments/issue41_ab_run03/summary.json` |
| `alt_spans.json` | RQ001~026 검수에서 제안한 동등 근거 구간(민감도 분석 입력) | 검수 중 수동 작성. 원본은 `retrieval_eval/rq001_026_gold_revision_proposal_20261110.json` |
| `eval_b2_06b_memory.json` | 최종 DB 0.6B 저장 벡터 + 메모리 정확 코사인 검색 결과(Qdrant 결과와 대조용) | `scripts/local_eval.py` |
| `b2_b3_compare.json` | B2 vs B3 청킹 비교(같은 0.6B 질의 벡터). 질문별 Top-10, Top-5/Top-10 채점, 정책 순위 | `scripts/compare_cfg.py` |
| `ab1_local_compare.json` | A/B 1 로컬 재현: 0.6B(최종 DB 저장 벡터) vs 4B(이 PC CPU로 새로 임베딩), 같은 B2 1,138 청크 | `scripts/compare_cfg.py` |
| `timing_bench.json` | 로컬 CPU 시간 측정(워밍업 후 3회, 회차마다 모델 순서 교대) | `scripts/timing_bench.py` |
| `embed_4b.log`, `embed_b3.log` | 로컬 청크 임베딩 진행 기록(4B 1,138개 7,630초, B3 0.6B 1,220개) | `scripts/ab_local_embed_cfg.py` |

## 저장소에 넣지 않은 대용량 벡터 파일 (SHA-256)

벡터 파일은 크기 때문에 넣지 않았다. 아래 스크립트로 다시 만들 수 있다. CPU 부동소수점 차이로 해시는 재생성 시 달라질 수 있다.

| 파일 | 크기 | SHA-256 | 생성 |
|---|---:|---|---|
| `rec06.pkl` (최종 DB 0.6B 1,138 Point 스냅샷) | 12.4MB | `c0c56e5661317be90497711c2c844a6371779275981ead17d0316fcdfa739914` | `scan06.py` (Qdrant scroll, 읽기 전용) |
| `chunks_4b.jsonl` (B2 × 4B, 2,560차원) | 39.8MB | `73c8ffc5088e6fd4297fbb481408073b3ac6e472a6d862215a9c5f909e85f1c3` | `ab_local_embed_cfg.py qwen3-embedding:4b 2560 <out>` |
| `chunks_b3_06b.jsonl` (B3 × 0.6B, 1,024차원) | 16.9MB | `c82a5cdb0efcb31bcd513f9b29b57172acadae3498c6e9dcb8aac59a884a2e04` | `ab_local_embed_cfg.py qwen3-embedding:0.6b 1024 <out> B_B3_V140` |
| `queries_06b_finaldb.json` (55 질의 × 0.6B) | 0.8MB | `aa763b1496159e71f2fa6c8750735a2210da0d9351de9f4e4514c4d295671705` | `ab_local_queries.py qwen3-embedding:0.6b 1024 <out> --qdrant` |
| `queries_4b_local.json` (55 질의 × 4B) | 1.9MB | `27e820bd4c54d859707b6facec456a6f305fa0414b8c6cd12864be5692f1a59f` | `ab_local_queries.py qwen3-embedding:4b 2560 <out>` |

## 스크립트 사용 시 주의

- 모든 스크립트는 저장소 루트(worktree)를 현재 폴더로 두고 실행한다(`database` 패키지 import).
- `compare_cfg.py <작업폴더> '<JSON 목록>' <출력파일명>`: 벡터·질의 경로는 작업폴더 기준 상대 경로, 출력은 `<작업폴더>/ab_local/<출력파일명>`.
- `timing_bench.py <작업폴더> <env 파일>`: Qdrant 접속 정보는 환경 변수 또는 지정 env 파일에서 읽고 값은 출력하지 않는다.
- 이 스크립트들은 평가용 일회성 도구이며 서비스 코드가 아니다. 팀 공용 평가 도구는 `database/retrieval_v140_eval.py`다.
