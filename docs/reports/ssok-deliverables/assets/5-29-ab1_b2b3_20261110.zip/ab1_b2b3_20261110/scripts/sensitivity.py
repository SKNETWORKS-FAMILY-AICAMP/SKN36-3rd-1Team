"""민감도 분석: 제안 대체 근거를 '같은 필수 근거의 추가 대안'으로 인정했을 때의 재채점(공식 수치 대체 아님)."""
import json, sys
summary = json.load(open(sys.argv[1], encoding="utf-8"))
alts = json.load(open(sys.argv[2], encoding="utf-8"))
gold = {q["question_id"]: q for q in map(json.loads, open("docs/development/retrieval_eval/questions_candidates_v0.jsonl", encoding="utf-8"))}
extra = {}
for a in alts:
    extra.setdefault(a["question_id"], []).append(a)
def contains(h, a):
    return h["document_id"] == a["document_id"] and h["char_start"] is not None and h["char_start"] <= a["char_start"] and a["char_end"] <= h["char_end"]
def rank(q, hits, use_extra):
    ranks = []
    for e in q["gold"]["required"]:
        options = list(e["alternatives"])
        if use_extra:
            # RQ019는 근거 2개가 각각 다른 문장이므로 같은 텍스트의 대안만 붙인다.
            options += [a for a in extra.get(q["question_id"], []) if q["question_id"] != "RQ019" or a["evidence_text"] == e["evidence_text"]]
        ranks.append(next((h["rank"] for h in hits if any(contains(h, a) for a in options)), None))
    return None if None in ranks else max(ranks)
for name, res in summary["results"].items():
    rows = {r["question_id"]: r for r in res["questions"] if r["answerable"]}
    base = {q: rank(gold[q], r["hits"], False) for q, r in rows.items()}
    alt = {q: rank(gold[q], r["hits"], True) for q, r in rows.items()}
    ch = {q: (base[q], alt[q]) for q in rows if base[q] != alt[q]}
    m = lambda d: (sum(v is not None for v in d.values()), round(sum(1 / v for v in d.values() if v) / len(d), 6))
    print(name, "base hits/MRR", m(base), "with proposed alternatives", m(alt), "changed", ch)
