"""메모리 정확 코사인 Top-5 검색 + 기존 채점 함수(rv.score_question) 재사용. DB 쓰기 없음."""
import json, pickle, sys, time
import numpy as np
sys.path.insert(0, ".")
from database import full_index as fi, handoff_data as hd, retrieval_eval as rv
from database.retrieval_v140_eval import load_cases

def load_index(config, vectors):
    docs = hd.load_documents(verify_hash=True)
    chunks, _ = fi.build_config_chunks(config, docs)
    by_pid = {c["point_id"]: c for c in chunks}
    if vectors.endswith(".pkl"):
        rec = pickle.load(open(vectors, "rb")); vec = {k: v["vector"] for k, v in rec.items()}
    else:
        vec = {r["point_id"]: r["vector"] for r in map(json.loads, open(vectors, encoding="utf-8"))}
    if set(vec) != set(by_pid):
        raise ValueError(f"{config}: 벡터 {len(vec)}개와 청크 {len(by_pid)}개 ID 불일치")
    ids = sorted(by_pid)
    m = np.array([vec[i] for i in ids], dtype=np.float32)
    m /= np.linalg.norm(m, axis=1, keepdims=True)
    return docs, [by_pid[i] for i in ids], m

def search(meta, m, qv, k=5):
    q = np.asarray(qv, dtype=np.float32); q /= np.linalg.norm(q)
    s = m @ q; top = np.argsort(-s, kind="stable")[:k]
    return [{"rank": r, "score": float(s[i]), "chunk_id": meta[i]["chunk_id"], "document_id": meta[i]["document_id"],
             "policy_id": meta[i]["policy_id"], "char_start": meta[i]["char_start"], "char_end": meta[i]["char_end"]}
            for r, i in enumerate(top, 1)]

def evaluate(config, vectors, queries):
    docs, meta, m = load_index(config, vectors)
    cases = {c["id"]: c for c in load_cases(docs, v0_only=True)[0]}
    qrows = json.load(open(queries, encoding="utf-8"))
    rows = []
    for r in qrows:
        t = time.perf_counter(); hits = search(meta, m, r["vector"]); st = time.perf_counter() - t
        rows.append({"question_id": r["question_id"], "answerable": r["answerable"], "hits": hits,
                     "score": rv.score_question(cases[r["question_id"]]["v0"], hits, k=5),
                     "embedding_seconds": r["embedding_seconds"], "memory_search_seconds": st})
    sc = [x for x in rows if x["answerable"]]
    return {"config": config, "chunks": len(meta), "scored": len(sc),
            "recall_at_5": sum(x["score"]["outcome"] == "hit" for x in sc) / len(sc),
            "mrr_at_5": sum(x["score"]["reciprocal_rank"] for x in sc) / len(sc), "questions": rows}

if __name__ == "__main__":
    config, vectors, queries, out = sys.argv[1:5]
    res = evaluate(config, vectors, queries)
    json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False)
    print(config, res["chunks"], "recall@5", round(res["recall_at_5"], 6), "mrr@5", round(res["mrr_at_5"], 6))
