import json, sys, pickle
from database.qdrant import store
from database.embedding_resume import scan
from database.ab_eval_state import digest
client = store.get_client()
rec = scan(client, "exp_b2_qwen3emb06b_v140_v1")
client.close()
print("points", len(rec))
print("full_digest", digest(rec))
print("vector_digest", digest({k: v["vector"] for k, v in rec.items()}))
print("payload_digest", digest({k: v["payload"] for k, v in rec.items()}))
pickle.dump(rec, open(sys.argv[1], "wb"))
