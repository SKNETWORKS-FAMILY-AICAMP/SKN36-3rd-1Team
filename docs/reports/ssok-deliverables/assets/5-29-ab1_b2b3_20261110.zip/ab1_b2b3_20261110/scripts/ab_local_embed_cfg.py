"""DB 쓰기 없이 B2 1,138 청크를 지정 모델로 임베딩해 JSONL에 저장(이어하기 지원)."""
import json, sys, time
sys.path.insert(0, ".")
from database import embedding as em, full_index as fi, handoff_data as hd
from database.qdrant import store
model, dim, out = sys.argv[1], int(sys.argv[2]), sys.argv[3]
config = sys.argv[4] if len(sys.argv) > 4 else "A_B2_V140"
docs = hd.load_documents(verify_hash=True); meta = hd.load_payload_metadata()
chunks, _ = fi.build_config_chunks(config, docs)
texts = [em.build_embedding_text(c, store.metadata_for_chunk(meta, c), fi.EMBEDDING_INPUT_RULE) for c in chunks]
done = set()
try:
    for line in open(out, encoding="utf-8"):
        done.add(json.loads(line)["point_id"])
except FileNotFoundError:
    pass
todo = [i for i, c in enumerate(chunks) if c["point_id"] not in done]
print(f"{model}: total {len(chunks)} done {len(done)} todo {len(todo)}", flush=True)
embed = em.make_ollama_embedder(model=model, expected_dim=dim, batch_size=8, timeout=1800)
started = time.perf_counter()
with open(out, "a", encoding="utf-8") as f:
    for n in range(0, len(todo), 8):
        idx = todo[n:n + 8]
        vecs = em.validate_vectors(embed([texts[i] for i in idx]), len(idx), dim)
        for i, v in zip(idx, vecs):
            f.write(json.dumps({"point_id": chunks[i]["point_id"], "chunk_id": chunks[i]["chunk_id"], "vector": [float(x) for x in v]}) + "\n")
        f.flush()
        if (n // 8) % 10 == 0:
            print(f"{n + len(idx)}/{len(todo)} {time.perf_counter() - started:.0f}s", flush=True)
print("DONE", f"{time.perf_counter() - started:.0f}s", flush=True)
