"""run summary 독립 재계산: 채점 함수를 호출하지 않고 문서 ID·문자 구간 포함으로 재판정."""
import json, math, statistics, sys
summary = json.load(open(sys.argv[1], encoding="utf-8"))
gold = {q["question_id"]: q for q in map(json.loads, open("docs/development/retrieval_eval/questions_candidates_v0.jsonl", encoding="utf-8"))}
def rank_all(q, hits):
    ranks = []
    for e in q["gold"]["required"]:
        r = next((h["rank"] for h in hits for a in e["alternatives"]
                  if h["document_id"] == a["document_id"] and h["char_start"] is not None
                  and h["char_start"] <= a["char_start"] and a["char_end"] <= h["char_end"]), None)
        ranks.append(r)
    return None if None in ranks else max(ranks)
def p95(v):
    s = sorted(v); return s[math.ceil(len(s) * .95) - 1]
out = {}
for name, res in summary["results"].items():
    rows = res["questions"]; per = {}
    for r in rows:
        if not r["answerable"]: continue
        rk = rank_all(gold[r["question_id"]], r["hits"])
        per[r["question_id"]] = rk
        assert (rk is not None) == (r["score"]["outcome"] == "hit"), (name, r["question_id"])
    def metrics(ids):
        ids = [i for i in ids if i in per]
        return {"n": len(ids), "hits": sum(per[i] is not None for i in ids),
                "recall@5": sum(per[i] is not None for i in ids) / len(ids),
                "mrr@5": sum(1 / per[i] for i in ids if per[i]) / len(ids)}
    emb = [r["embedding_seconds"] * 1000 for r in rows]; sea = [r["search_seconds"] * 1000 for r in rows]
    comb = [a + b for a, b in zip(emb, sea)]
    allq = sorted(per); mine = [i for i in allq if int(i[2:]) <= 26]; theirs = [i for i in allq if int(i[2:]) > 26]
    out[name] = {"all52": metrics(allq), "rq001_026": metrics(mine), "rq027_052": metrics(theirs),
                 "reported": (res["preliminary_recall_at_5"], res["preliminary_mrr_at_5"]),
                 "latency_ms": {k: (round(statistics.mean(v), 2), round(p95(v), 2), len(v)) for k, v in
                                (("embedding", emb), ("search", sea), ("combined", comb))},
                 "reported_latency": {k: (round(res[k]["mean_ms"], 2), round(res[k]["p95_ms"], 2)) for k in ("embedding", "search", "combined")},
                 "ranks": per}
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for name, o in out.items():
    print(name, {k: o[k] for k in ("all52", "rq001_026", "rq027_052", "reported", "latency_ms", "reported_latency")})
