"""질의 임베딩·검색 시간 반복 측정(로컬 CPU). 워밍업 후 3회, 회차마다 모델 순서 교대. DB 쓰기 없음.

측정 구간
- embedding: embedder([질문]) 호출 시작~벡터 반환(HTTP 왕복 포함, 모델 로딩은 워밍업으로 제외)
- memory_search: 정규화 행렬 곱 + 정렬(두 모델 동일 방식)
- qdrant_search(0.6B만): store.search_chunks 호출 시작~결과 반환
- combined = embedding + memory_search (두 모델 같은 기준)
"""
import json, math, platform, statistics, sys, time
import requests
sys.path.insert(0, ".")
sys.path.insert(0, sys.argv[1])
from local_eval import load_index, search
from database import embedding as em, handoff_data as hd
from database.retrieval_v140_eval import load_cases
from database.qdrant import store
SP = sys.argv[1]
MODELS = {"0.6b": ("qwen3-embedding:0.6b", 1024, SP + "/rec06.pkl"), "4b": ("qwen3-embedding:4b", 2560, SP + "/ab_local/chunks_4b.jsonl")}
docs = hd.load_documents(verify_hash=True)
cases = load_cases(docs, v0_only=True)[0]
index = {k: load_index("A_B2_V140", v[2])[1:] for k, v in MODELS.items()}
embedders = {k: em.make_ollama_embedder(model=v[0], expected_dim=v[1], batch_size=1, timeout=1800) for k, v in MODELS.items()}
store.load_project_env(sys.argv[2])  # 값 출력 없음
client = store.get_client()
def p95(v): s = sorted(v); return s[math.ceil(len(s) * .95) - 1]
first_call = {}
for k in MODELS:  # 첫 호출(로딩 포함 가능) 별도 기록
    t = time.perf_counter(); embedders[k]([cases[0]["query"]]); first_call[k] = time.perf_counter() - t
samples = {k: {"embedding": [], "memory_search": [], "qdrant_search": []} for k in MODELS}
rounds = []
for rnd in range(3):
    order = ["0.6b", "4b"] if rnd % 2 == 0 else ["4b", "0.6b"]
    for k in order:
        for c in cases[:3]:
            embedders[k]([c["query"]])  # 워밍업(기록 안 함)
        ps = requests.get(em.resolve_ollama_base_url().rstrip("/") + "/api/ps", timeout=10).json()
        for c in cases:
            t = time.perf_counter(); vec = embedders[k]([c["query"]])[0]; e = time.perf_counter() - t
            meta, m = index[k]
            t = time.perf_counter(); search(meta, m, vec); s = time.perf_counter() - t
            samples[k]["embedding"].append(e); samples[k]["memory_search"].append(s)
            if k == "0.6b":
                t = time.perf_counter(); store.search_chunks(client, "exp_b2_qwen3emb06b_v140_v1", vec, k=5, filters=None)
                samples[k]["qdrant_search"].append(time.perf_counter() - t)
        rounds.append({"round": rnd + 1, "model": k, "loaded_models": [(x["name"], x.get("size_vram")) for x in ps.get("models", [])],
                       "mean_embedding_ms": statistics.mean(samples[k]["embedding"][-55:]) * 1000})
client.close()
out = {"environment": {"cpu": platform.processor(), "platform": platform.platform(), "python": platform.python_version(),
                       "ollama_version": requests.get(em.resolve_ollama_base_url().rstrip("/") + "/api/version", timeout=10).json()["version"],
                       "device": "CPU only (no NVIDIA GPU detected)", "batch_size": 1, "rounds": 3, "warmup_queries_per_round": 3,
                       "questions_per_round": len(cases)},
       "first_call_seconds": first_call, "rounds": rounds, "summary": {}}
for k, d in samples.items():
    comb = [a + b for a, b in zip(d["embedding"], d["memory_search"])]
    out["summary"][k] = {name: {"samples": len(v), "mean_ms": statistics.mean(v) * 1000, "p95_ms": p95(v) * 1000,
                                "stdev_ms": statistics.stdev(v) * 1000} for name, v in
                         (("embedding", d["embedding"]), ("memory_search", d["memory_search"]), ("combined", comb),
                          *((("qdrant_search", d["qdrant_search"]),) if d["qdrant_search"] else ()))}
    out["summary"][k]["round_means_ms"] = [r["mean_embedding_ms"] for r in rounds if r["model"] == k]
json.dump(out, open(SP + "/ab_local/timing_bench.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(out["summary"], ensure_ascii=False, indent=1)); print("first_call", first_call)
