import json, sys
from collections import Counter
sys.path.insert(0, "."); sys.path.insert(0, sys.argv[1])
from local_eval import load_index, search
from database import retrieval_eval as rv
from database.retrieval_v140_eval import load_cases
SP = sys.argv[1]
specs = json.loads(sys.argv[2])  # [[label, config, vectors, queries], ...]
out = {}
for label, config, vectors, queries in specs:
    vectors, queries = SP + "/" + vectors, SP + "/" + queries
    docs, meta, m = load_index(config, vectors)
    cases = {c["id"]: c for c in load_cases(docs, v0_only=True)[0]}
    q = json.load(open(queries, encoding="utf-8"))
    rows = []
    for r in q:
        hits = search(meta, m, r["vector"], k=10)
        s5 = rv.score_question(cases[r["question_id"]]["v0"], hits, k=5)
        s10 = rv.score_question(cases[r["question_id"]]["v0"], hits, k=10)
        pol = cases[r["question_id"]]["v0"]["policy_ids"]
        prank = next((h["rank"] for h in hits[:5] if h["policy_id"] in pol), None)
        rows.append({"question_id": r["question_id"], "answerable": r["answerable"], "hits": hits[:5], "hits_6_10": hits[5:],
                     "score5": s5, "score10": s10, "policy_rank5": prank})
    sc = [x for x in rows if x["answerable"]]
    lens = sorted(c["char_end"] - c["char_start"] for c in meta)
    out[label] = {"config": config, "chunks": len(meta), "documents": len({c["document_id"] for c in meta}),
                  "median_chars": lens[len(lens) // 2], "max_chars": lens[-1],
                  "recall5": sum(x["score5"]["outcome"] == "hit" for x in sc), "mrr5": sum(x["score5"]["reciprocal_rank"] for x in sc) / 52,
                  "recall10": sum(x["score10"]["outcome"] == "hit" for x in sc), "mrr10": sum(x["score10"]["reciprocal_rank"] for x in sc) / 52,
                  "policy_hit5": sum(x["policy_rank5"] is not None for x in sc),
                  "outcomes5": dict(Counter(x["score5"]["outcome"] for x in sc)),
                  "fail5": [x["question_id"] for x in sc if x["score5"]["outcome"] != "hit"], "questions": rows}
    o = out[label]
    print(label, {k: (round(v, 6) if isinstance(v, float) else v) for k, v in o.items() if k != "questions"})
json.dump(out, open(SP + "/ab_local/" + sys.argv[3], "w", encoding="utf-8"), ensure_ascii=False)
