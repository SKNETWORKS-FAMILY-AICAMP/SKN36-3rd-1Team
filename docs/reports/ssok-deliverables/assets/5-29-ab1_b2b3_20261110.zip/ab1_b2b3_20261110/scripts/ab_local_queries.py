"""55 질의 임베딩 저장(+선택: 최종 Qdrant 0.6B 검색·채점). DB 쓰기 없음."""
import json, sys, time
sys.path.insert(0, ".")
from database import embedding as em, handoff_data as hd, retrieval_eval as rv
from database.retrieval_v140_eval import load_cases
model, dim, out = sys.argv[1], int(sys.argv[2]), sys.argv[3]
search = len(sys.argv) > 4 and sys.argv[4] == "--qdrant"
docs = hd.load_documents(verify_hash=True)
cases, audit = load_cases(docs, v0_only=True)
print("cases", len(cases), "span checks ok", all(c["exact_match"] for c in audit["v0_span_checks"]), flush=True)
embed = em.make_ollama_embedder(model=model, expected_dim=dim, batch_size=1, timeout=1800)
rows = []
if search:
    from database.qdrant import store
    client = store.get_client()
for case in cases:
    t = time.perf_counter(); vec = em.validate_vectors(embed([case["query"]]), 1, dim)[0]; et = time.perf_counter() - t
    row = {"question_id": case["id"], "answerable": case["v0"]["answerable"], "vector": [float(x) for x in vec], "embedding_seconds": et}
    if search:
        t = time.perf_counter(); hits = store.search_chunks(client, "exp_b2_qwen3emb06b_v140_v1", vec, k=5, filters=None); st = time.perf_counter() - t
        hits = [{**h, "char_start": h["payload"].get("char_start"), "char_end": h["payload"].get("char_end")} for h in hits]
        row["score"] = rv.score_question(case["v0"], hits, k=5); row["search_seconds"] = st
        row["hits"] = [{k: h.get(k) for k in ("rank", "score", "chunk_id", "document_id", "policy_id", "char_start", "char_end")} for h in hits]
    rows.append(row)
if search: client.close()
json.dump(rows, open(out, "w", encoding="utf-8"))
if search:
    sc = [r for r in rows if r["answerable"]]
    print("recall@5", sum(r["score"]["outcome"] == "hit" for r in sc) / len(sc), "mrr@5", sum(r["score"]["reciprocal_rank"] for r in sc) / len(sc), len(sc))
